import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-print-request',
  templateUrl: './print-request.component.html',
  styleUrls: ['./print-request.component.css']
})
export class PrintRequestComponent implements OnInit {
  printName: any;
  name: any;
  address: any;
  phnNo1: any;
  phnNo2: any;
  partyName: any;
  printType: any;
  printStatus: any;
  wide: any;
  hight: any;
  quantity: any;
  fileName: any;
  frameAdd: any;

  this_array = [];
  db_push_array = [];
  db_push_array_size: any;

  constructor() { }

  ngOnInit() {
    this.get_array_length();
  }

  check() {
    // this.get_array();
    this.db_push_array.push(this.get_array());
    this.get_array_length();
    console.log(this.db_push_array);
    this.clear_form();
  }

  get_array() {
    const temp = {
      'printName': this.printName,
      'name' : this.name,
      'address': this.address,
      'phnNo1': this.phnNo1,
      'phnNo2': this.phnNo2,
      'partyName': this.partyName,
      'printType': this.printType,
      'printStatus': this.printStatus,
      'wide': this.wide,
      'hight': this.hight,
      'quantity': this.quantity,
      'fileName': this.fileName,
      'frameAdd': this.frameAdd
    };
    return temp;
  }

  get_array_length() {
    if (this.db_push_array.length === 0) {
      this.db_push_array_size = 0;
    } else {
       this.db_push_array_size = this.db_push_array.length;
    }
  }

  clear_form() {
    this.printName = '';
    this.name = '';
    this.address = '';
    this.phnNo1 = '';
    this.phnNo2 = '';
    this.partyName = '';
    this.printType = '';
    this.printStatus = '';
    this.wide = '';
    this.hight = '';
    this.quantity = '';
    this.fileName = '';
    this.frameAdd = '';
  }
}
