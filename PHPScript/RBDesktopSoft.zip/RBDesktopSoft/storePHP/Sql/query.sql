SELECT DISTINCT account.BillNo, account.AIid as id, client_details.name, 
    client_details.address, client_details.phoneNo1, 
    client_details.PartyName, printdetails.PrintType, 
    printdetails.wide, printdetails.height, printdetails.sft, 
    printdetails.quantity, printdetails.Frame, printdetails.CreatedTime, 
    printdetails.CreatedDate FROM account, client_details, printdetails 
    where account.BillNo = "67ff6a7086d261dc943a2e7338ca6ab8" 
    and client_details.BillNo = account.BillNo 
    and printdetails.BillNo = account.BillNo 
    and client_details.AIid = account.AIid 
    and printdetails.AIid = account.AIid