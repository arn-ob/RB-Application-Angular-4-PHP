
<?php
/* server timezone */
date_default_timezone_set("Asia/Dhaka");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rbsoft";


?>