
<?php

// header_remove('Access-Control-Allow-Origin');
// header('Access-Control-Allow-Origin: *');

header('Access-Control-Allow-Origin: *');

header('Access-Control-Allow-Methods: GET, POST');

header("Access-Control-Allow-Headers: X-Requested-With");


/* server timezone */
date_default_timezone_set("Asia/Dhaka");

header_remove('Access-Control-Allow-Origin');
header('Access-Control-Allow-Origin: *');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rbsoft";


?>