<?php

// Here Only store the info of Client Data and 
include "../_db/db.php";


// get data from angular
$data = file_get_contents('php://input'); // put the contents of the file into a variable
$receive = json_decode($data); // decode the JSON feed

// Get the bill
$sql  = $receive->sql;



// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$myArray = array();
if ($result = $conn->query($sql)) {
    
    while($row = $result->fetch_array(MYSQL_ASSOC)) {
            $myArray[] = $row;
    }
    echo json_encode($myArray);
}


$conn->close();
?> 