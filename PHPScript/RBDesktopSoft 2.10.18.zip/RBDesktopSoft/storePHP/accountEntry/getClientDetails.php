<?php

// Here Only store the info of Client Data and 
include "../_db/db.php";

// get data from angular
$data = file_get_contents('php://input'); // put the contents of the file into a variable
$receive = json_decode($data); // decode the JSON feed

$billNo  = $receive->billNo;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// if for preventing null value 

$sql="SELECT DISTINCT  * FROM  client_details where client_details.BillNo = '$billNo'";
   

$myArray = array();
if ($result = $conn->query($sql)) {
    
    if($row = $result->fetch_array(MYSQL_ASSOC)) {
            $myArray[] = $row;
    }
    echo json_encode($myArray);
}

$result->close();
$conn->close();
?> 