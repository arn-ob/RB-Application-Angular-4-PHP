
<?php

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');


/* server timezone */
date_default_timezone_set("Asia/Dhaka");

// header_remove('Access-Control-Allow-Origin');
// header('Access-Control-Allow-Origin: *');

$servername = "localhost";
$username = "revolutionbd_admin";
$password = "ZNa]M[3!ufH]";
$dbname = "revolutionbd_rbsoftweb";


?>