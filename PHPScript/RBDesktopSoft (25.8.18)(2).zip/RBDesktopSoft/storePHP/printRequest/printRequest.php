 <?php

// Here Only store the info of Client Data and 
include "../_db/db.php";


// get data from angular
$data = file_get_contents('php://input'); // put the contents of the file into a variable
$receive = json_decode($data); // decode the JSON feed

// Get the bill
$billNo  = $receive->billID;
$AIid  = $receive->AIid;

// Client Details
$ClientName    = $receive->name;
$ClientAddress = $receive->address;
$ClientPhnNo1 =   $receive->phnNo1;
$ClientPhnNo2 =   $receive->phnNo2;
$partyName = $receive->partyName;
$printName = $receive->printName;

// Print Details
$PrintType =     $receive->printType;
$PrintHeight =   $receive->hight;
$PrintWide =     $receive->wide;
$PrintQuntity =  $receive->quantity;
$frame =    $receive->frameAdd;
$fileName = $receive->fileName;

$sft = $PrintHeight * $PrintWide;

// Date 
$time = date("h:i:sa");
$date = date("Y/m/d");

// Date not to include : /
$dateEn = date("Ymd");
$timeEn = date("hi");


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// if for preventing null value 

if($billNo == ""){ 
    echo "null";    
}else {
    $clientDetails = "INSERT INTO client_details (AIid, name, address, phoneNo1, phoneNo2, BillNo, PartyName,CreatedDate, CreatedTime) 
                              VALUES ('$AIid','$ClientName', '$ClientAddress', '$ClientPhnNo1', '$ClientPhnNo2', '$billNo', '$partyName', '$date', '$time')";
    
    
    $printDetails = "INSERT INTO printdetails (AIid, BillNo, printName, PrintType, wide, height, sft, quantity, FileName, Frame, CreatedTime, CreatedDate) 
                            VALUES ('$AIid','$billNo', '$printName',  '$PrintType', '$PrintWide', '$PrintHeight', '$sft','$PrintQuntity', '$fileName', '$frame', '$time', '$date')";

    $account= "INSERT INTO account (AIid, BillNo, quantity, type, totalSFT, CreatedTime, CreatedDate) 
                    VALUES ('$AIid','$billNo', '$PrintQuntity', '$PrintType', '$sft', '$time', '$date')";

    // $printStatusSQL  = "INSERT INTO printstatus (BilNo, ClientName, FileName, sft , quantity, CreatedDate, CreatedTime, Status) 
    //                     VALUES ('$EntrybillNo', '$ClientName', '$fileName', '$Sft', '$PrintQuntity', '$date', '$time', '$PrintStatus')";


    $myArray = array();
    // Storing Data
    if ($conn->query($clientDetails) === TRUE) 
    {
        if ($conn->query($printDetails) === TRUE) 
        {
            if ($conn->query($account) === TRUE) 
            {   
                $myArray[] = ["status" => "Done"];
                echo json_encode($myArray);
            }
        }
   } else {
        echo "Problem";
   }
    
}


$conn->close();
?> 