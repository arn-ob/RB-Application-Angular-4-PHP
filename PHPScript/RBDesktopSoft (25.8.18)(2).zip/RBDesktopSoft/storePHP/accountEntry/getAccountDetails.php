 <?php

// Here Only store the info of Client Data and 
include "../_db/db.php";


// get data from angular
$data = file_get_contents('php://input'); // put the contents of the file into a variable
$receive = json_decode($data); // decode the JSON feed

// Get the bill
$billNo  = $receive->billNo;



// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql="SELECT DISTINCT account.BillNo, account.AIid as id, account.advance,
        client_details.name, client_details.address, 
        client_details.phoneNo1, client_details.PartyName, 
        printdetails.PrintType, printdetails.wide, printdetails.height, 
        printdetails.sft, printdetails.quantity, printdetails.Frame, 
        printdetails.CreatedTime, printdetails.CreatedDate, printdetails.FileName 
    FROM account, client_details, printdetails 
    where account.BillNo = '$billNo' and client_details.BillNo = account.BillNo and printdetails.BillNo = account.BillNo and client_details.AIid = account.AIid and printdetails.AIid = account.AIid";

$myArray = array();
if ($result = $conn->query($sql)) {
    
    while($row = $result->fetch_array(MYSQL_ASSOC)) {
            $myArray[] = $row;
    }
    echo json_encode($myArray);
}

$result->close();
$conn->close();
?> 