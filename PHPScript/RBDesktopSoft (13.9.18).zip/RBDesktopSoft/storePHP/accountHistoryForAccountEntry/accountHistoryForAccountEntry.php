<?php

// Here Only store the info of Client Data and 
include "../_db/db.php";



// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// if for preventing null value 

$sql="SELECT DISTINCT account.BillNo, client_details.name, client_details.phoneNo1, 
        client_details.PartyName, account.quantity, account.totalSFT, 
        printdetails.PrintType, printdetails.sft, printdetails.FileName, client_details.CreatedTime 
    FROM account, client_details, printdetails 
    where account.CreatedDate = CURRENT_DATE() 
    and client_details.BillNo = account.BillNo 
    and client_details.BillNo = account.BillNo 
    and client_details.BillNo = printdetails.BillNo 
    and client_details.AIid = account.AIid 
    and client_details.AIid = printdetails.AIid
    and account.advance = 0 
    GROUP BY account.BillNo";
   

$myArray = array();
if ($result = $conn->query($sql)) {
    
    while($row = $result->fetch_array(MYSQL_ASSOC)) {
            $myArray[] = $row;
    }
    echo json_encode($myArray);
}

$result->close();
$conn->close();
?> 